# What is this about?
This challenge is part of the KINEXON interview process. We would like to 
see where your skills and imagination take you based on the backend we
provide in this package. Do whatever you like and build something cool.

On the backend side, we would like you to implement the TODO written as a 
comment in server.js. If you feel the need to change anything else in the 
backend, you can do so (adding routes, refactoring the existing code etc). 
However, the focus of the challenge is building a frontend that does 
something creative with the data.

# Important Info
Please check that you have npm and node.js installed on your system
and npm and node are available in your path (console path).

# Intro
This package starts two servers.
One of them is for the backend, written in node and runs on port 3000.
The other server serves the static files on localhost:8080 from the 
directory app.

# Starting the servers
To start the servers run the shell script start.sh from the command line:
chmod 755 start.sh
./start.sh

# Usage
The backend server serves only one route:
GET http://localhost:3000/
The response is a list of objects containing some information and
a geographical position.
To see the index.html for the frontend, open your browser at:
http://localhost:8080/